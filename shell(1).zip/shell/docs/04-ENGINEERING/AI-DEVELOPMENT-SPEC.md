# AI Development Spec

## 1. 目标
- 统一 AI 协作开发的输出格式，让后续开发可快速识别：哪些已完成、哪些未完成、哪些有风险。
- 通过结构化注释与状态标记，降低重复开发、漏修和误判成本。

## 2. 强制要求（Must）
- 每个功能点必须有唯一功能编号（推荐：`FR-xx` 或 `TASK-xx`）。
- 每次代码改动必须在对应模块保留“功能注释块”（见模板）。
- 每次提交必须同步更新功能状态文档（至少更新 `FEATURE-STATUS` 或任务卡）。
- 存在已知问题时，必须记录“问题注释块”并标明影响范围与建议修复方向。

## 3. 功能注释块模板（代码内）
建议放置在模块入口、关键函数、关键流程节点附近。

```text
[AI-FEATURE]
ID: FR-xx / TASK-xx
Name: <功能名称>
Status: TODO | IN_PROGRESS | DONE | BLOCKED
Scope: <影响文件/模块>
Input: <输入>
Output: <输出>
Errors: <关键错误码或失败场景>
Tests: <已覆盖/待覆盖测试点>
Updated: <YYYY-MM-DD>
Owner: AI/Human
```

## 4. 问题注释块模板（代码内）
当发现缺陷、性能风险、兼容性问题时必须添加。

```text
[AI-ISSUE]
ID: BUG-xxx
Severity: S1 | S2 | S3 | S4
Status: OPEN | MITIGATED | RESOLVED
Symptom: <现象>
Condition: <触发条件>
Impact: <影响范围>
Workaround: <临时规避>
FixPlan: <建议修复方向>
Updated: <YYYY-MM-DD>
```

## 5. 状态定义
- `TODO`：已确认需求，尚未开始。
- `IN_PROGRESS`：开发中，未完成自测。
- `DONE`：实现完成并通过最小验证。
- `BLOCKED`：被依赖或外部条件阻塞。

## 6. AI 执行提示词规范（可直接复用）
将以下提示词用于开发前置约束：

```text
你是本项目的开发代理。必须严格遵循 docs 下的产品、架构、测试与发布文档。
本次任务除了实现功能，还必须完成“可持续交接”：
1) 在关键代码位置写入 [AI-FEATURE] 注释块，明确 ID、状态、输入输出、错误与测试覆盖；
2) 若发现问题，写入 [AI-ISSUE] 注释块，明确严重级别、触发条件、影响范围与修复建议；
3) 明确区分已完成、未完成、阻塞项，不得模糊描述；
4) 输出必须包含：需求理解、实现步骤、变更文件清单、测试结果、已知问题与下一步建议；
5) 不得引入未批准技术栈，不得跳过异常路径处理，不得省略状态更新。
```

## 7. 合入前检查清单
- 功能编号是否唯一且可追踪。
- 功能注释块是否覆盖关键路径。
- 已知问题是否有问题注释块与修复建议。
- 状态是否与 `FEATURE-STATUS/TASK-CARDS` 一致。
- 输出是否明确“已完成/未完成/有问题待修复”。

## Package Manager Policy
- Use `pnpm` only.
- Do not use `npm`; use `pnpm` only.
- Any generated scripts/commands must use `pnpm` equivalents.
